/** Next.js config (TypeScript-friendly) */
const nextConfig = {
  reactStrictMode: true,
};

module.exports = nextConfig;