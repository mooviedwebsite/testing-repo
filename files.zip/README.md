# Website01 — Advanced Blogging Platform (Starter)

This is a starter full-stack blogging platform built with Next.js + TypeScript, Tailwind CSS, Prisma (SQLite for local dev), and NextAuth.

Features included:
- Homepage with cards linking to posts
- Post page with unique ID and bookmark/save toggle
- New-post page (protected)
- Admin area skeleton (protected)
- API routes for posts & bookmarks (Prisma)
- NextAuth credentials auth + Prisma adapter
- Tailwind CSS UI and React-Quill editor

Quickstart (local)
1. Copy this project into a folder named `website01`.
2. Create `.env` from `.env.example` and set values.
3. Install:
   ```
   npm install
   ```
4. Generate Prisma client and run migration:
   ```
   npx prisma generate
   npx prisma migrate dev --name init
   ```
5. (Optional) Create an admin account via a quick script or using the API:
   - Use Prisma Studio:
     ```
     npx prisma studio
     ```
     Create a `User` with email, name, role = "ADMIN", and a hashed password (use bcrypt hash).
6. Start dev server:
   ```
   npm run dev
   ```
7. Open http://localhost:3000

Important env values
- DATABASE_URL
- NEXTAUTH_URL (e.g. http://localhost:3000)
- NEXTAUTH_SECRET (random string)

Packaging to ZIP
- From parent directory:
  - macOS / Linux:
    ```
    zip -r website01.zip website01
    ```
  - Windows PowerShell:
    ```
    Compress-Archive -Path website01 -DestinationPath website01.zip
    ```

What's next I can do for you
- Create an initial admin user script and seed data
- Provide a ready downloadable zip (if you prefer, I can provide a tar archive content you can reconstruct)
- Add image uploads (Cloudinary/S3), Algolia search, scheduled publishing, RSS, or richer role management
