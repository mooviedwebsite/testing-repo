/
├─ README.md
├─ package.json
├─ next.config.js
├─ tsconfig.json
├─ prisma/
│  └─ schema.prisma
├─ src/
│  ├─ pages/ (or app/ if using Next App Router)
│  │  ├─ index.tsx   # homepage with cards
│  │  ├─ posts/[id].tsx  # post page
│  │  ├─ admin/      # admin panel pages (protected)
│  │  ├─ new-post.tsx  # create post page (protected)
│  │  └─ search.tsx
│  ├─ components/
│  │  ├─ PostCard.tsx
│  │  └─ Header.tsx
│  ├─ lib/
│  │  ├─ db.ts
│  │  └─ auth.ts
│  └─ styles/
└─ .github/
   └─ workflows/ci.yml