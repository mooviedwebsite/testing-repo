import Link from "next/link";

type Props = {
  post: {
    id: number;
    title: string;
    excerpt?: string | null;
    slug: string;
  };
};

export default function PostCard({ post }: Props) {
  return (
    <article className="p-4 bg-white rounded shadow">
      <h3 className="text-lg font-semibold">
        <Link href={`/posts/${post.id}`}>
          <a>{post.title}</a>
        </Link>
      </h3>
      <p className="text-sm text-gray-600 mt-2">{post.excerpt || "No excerpt"}</p>
      <div className="mt-3">
        <Link href={`/posts/${post.id}`}>
          <a className="text-indigo-600 text-sm">Read more →</a>
        </Link>
      </div>
    </article>
  );
}