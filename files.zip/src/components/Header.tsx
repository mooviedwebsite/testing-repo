import Link from "next/link";
import { signIn, signOut, useSession } from "next-auth/react";

export default function Header() {
  const { data: session } = useSession();

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div>
          <Link href="/">
            <a className="font-bold text-xl">Website01</a>
          </Link>
        </div>
        <nav className="flex items-center gap-4">
          <Link href="/search"><a className="text-sm">Search</a></Link>
          <Link href="/new-post"><a className="text-sm">New Post</a></Link>
          <Link href="/admin"><a className="text-sm">Admin</a></Link>
          {session?.user ? (
            <>
              <span className="text-sm">Hi, {session.user.name || session.user.email}</span>
              <button className="text-sm underline" onClick={() => signOut()}>Sign out</button>
            </>
          ) : (
            <button className="text-sm underline" onClick={() => signIn()}>Sign in</button>
          )}
        </nav>
      </div>
    </header>
  );
}