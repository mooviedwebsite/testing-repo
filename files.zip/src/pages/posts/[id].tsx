import { GetServerSideProps } from "next";
import Header from "../../components/Header";
import { prisma } from "../../lib/prisma";
import { useSession } from "next-auth/react";
import React from "react";

type Props = {
  post: {
    id: number;
    title: string;
    content: string;
    createdAt: string;
  } | null;
  bookmarked: boolean;
};

export default function PostPage({ post, bookmarked }: Props) {
  const { data: session } = useSession();

  if (!post) {
    return (
      <div>
        <Header />
        <main className="container mx-auto px-4 py-8">
          <p>Post not found</p>
        </main>
      </div>
    );
  }

  return (
    <div>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold">{post.title}</h1>
        <p className="text-sm text-gray-500 mt-1">ID: {post.id} — {new Date(post.createdAt).toLocaleString()}</p>
        <div className="mt-6 prose max-w-none" dangerouslySetInnerHTML={{ __html: post.content }} />
        <div className="mt-6">
          {session?.user ? (
            <BookmarkButton postId={post.id} initialBookmarked={bookmarked} />
          ) : (
            <p className="text-sm">Sign in to bookmark this post.</p>
          )}
        </div>
      </main>
    </div>
  );
}

function BookmarkButton({ postId, initialBookmarked }: { postId: number; initialBookmarked: boolean }) {
  const [booked, setBooked] = React.useState(initialBookmarked);

  async function toggle() {
    const res = await fetch("/api/bookmarks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ postId }),
    });
    if (res.ok) {
      const json = await res.json();
      setBooked(json.bookmarked);
    }
  }

  return (
    <button onClick={toggle} className="px-4 py-2 bg-indigo-600 text-white rounded">
      {booked ? "Saved" : "Save"}
    </button>
  );
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const id = Number(ctx.params?.id);
  const post = await prisma.post.findUnique({
    where: { id },
    select: { id: true, title: true, content: true, createdAt: true },
  });

  // server-side check for bookmark if session token present: skip for simplicity
  // For local dev we can return false by default
  return {
    props: {
      post: post ? JSON.parse(JSON.stringify(post)) : null,
      bookmarked: false,
    },
  };
};