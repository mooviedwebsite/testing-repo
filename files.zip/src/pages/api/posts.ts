import type { NextApiRequest, NextApiResponse } from "next";
import { prisma } from "../../lib/prisma";
import { getServerSession } from "next-auth/next";
import authOptions from "./auth/[...nextauth]";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === "GET") {
    const search = String(req.query.search || "");
    const posts = await prisma.post.findMany({
      where: search ? {
        OR: [
          { title: { contains: search, mode: "insensitive" } },
          { content: { contains: search, mode: "insensitive" } }
        ]
      } : undefined,
      select: { id: true, title: true, excerpt: true, slug: true },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return res.json(posts);
  }

  if (req.method === "POST") {
    // create post (protected)
    const session = await getServerSession(req, res, authOptions);
    if (!session?.user) return res.status(401).json({ error: "Unauthorized" });
    const { title, content, published } = req.body;
    const slug = title.toLowerCase().replace(/[^\w]+/g, "-").slice(0, 200);
    const post = await prisma.post.create({
      data: {
        title,
        content,
        excerpt: content?.slice(0, 200),
        slug,
        published: !!published,
        author: { connect: { email: session.user.email as string } },
      },
    });
    return res.status(201).json(post);
  }

  res.setHeader("Allow", ["GET", "POST"]);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}