import type { NextApiRequest, NextApiResponse } from "next";
import { prisma } from "../../lib/prisma";
import { getServerSession } from "next-auth/next";
import authOptions from "./auth/[...nextauth]";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  if (!session?.user) return res.status(401).json({ error: "Unauthorized" });

  if (req.method === "GET") {
    const bookmarks = await prisma.bookmark.findMany({
      where: { user: { email: session.user.email } },
      include: { post: true },
    });
    return res.json(bookmarks);
  }

  if (req.method === "POST") {
    const { postId } = req.body;
    const user = await prisma.user.findUnique({ where: { email: session.user.email as string } });
    if (!user) return res.status(404).json({ error: "User not found" });
    const existing = await prisma.bookmark.findUnique({ where: { userId_postId: { userId: user.id, postId } } });
    if (existing) {
      await prisma.bookmark.delete({ where: { id: existing.id } });
      return res.json({ bookmarked: false });
    } else {
      await prisma.bookmark.create({ data: { userId: user.id, postId } });
      return res.json({ bookmarked: true });
    }
  }

  res.setHeader("Allow", ["GET", "POST"]);
  res.status(405).end();
}