import Header from "../../components/Header";
import Link from "next/link";
import { prisma } from "../../lib/prisma";
import type { GetServerSideProps } from "next";

type Props = {
  posts: { id: number; title: string; published: boolean }[];
};

export default function Admin({ posts }: Props) {
  // NOTE: This page should be protected - for demo it's server-side rendered
  return (
    <div>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">Admin Panel</h1>
        <p className="mb-4">Manage posts</p>
        <Link href="/new-post"><a className="text-indigo-600">Create new post</a></Link>
        <ul className="mt-4 space-y-2">
          {posts.map((p) => (
            <li key={p.id} className="p-3 bg-white rounded shadow flex justify-between">
              <div>
                <div className="font-semibold">{p.title}</div>
                <div className="text-sm text-gray-500">{p.published ? "Published" : "Draft"}</div>
              </div>
              <div className="space-x-2">
                <button className="text-sm text-red-600">Delete</button>
              </div>
            </li>
          ))}
        </ul>
      </main>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  const posts = await prisma.post.findMany({ select: { id: true, title: true, published: true } });
  return {
    props: {
      posts: JSON.parse(JSON.stringify(posts)),
    },
  };
};