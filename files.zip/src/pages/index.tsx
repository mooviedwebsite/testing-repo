import type { GetServerSideProps } from "next";
import Header from "../components/Header";
import PostCard from "../components/PostCard";
import { prisma } from "../lib/prisma";

type Props = {
  posts: {
    id: number;
    title: string;
    excerpt?: string | null;
    slug: string;
  }[];
};

export default function Home({ posts }: Props) {
  return (
    <div>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Latest posts</h1>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.map((p) => (
            <PostCard key={p.id} post={p} />
          ))}
        </div>
      </main>
    </div>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  const posts = await prisma.post.findMany({
    where: { published: true },
    orderBy: { createdAt: "desc" },
    select: { id: true, title: true, excerpt: true, slug: true },
    take: 30,
  });
  return {
    props: {
      posts: JSON.parse(JSON.stringify(posts)),
    },
  };
};