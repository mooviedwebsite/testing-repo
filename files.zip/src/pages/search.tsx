import Header from "../components/Header";
import { useState } from "react";
import PostCard from "../components/PostCard";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);

  async function doSearch(e?: React.FormEvent) {
    if (e) e.preventDefault();
    const res = await fetch(`/api/posts?search=${encodeURIComponent(query)}`);
    if (res.ok) {
      const data = await res.json();
      setResults(data);
    }
  }

  return (
    <div>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">Search</h1>
        <form onSubmit={doSearch} className="flex gap-2 mb-6">
          <input value={query} onChange={(e) => setQuery(e.target.value)} className="flex-1 p-2 border" placeholder="Search posts..." />
          <button className="px-4 py-2 bg-indigo-600 text-white rounded">Search</button>
        </form>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {results.map((r) => (
            <PostCard key={r.id} post={r} />
          ))}
        </div>
      </main>
    </div>
  );
}