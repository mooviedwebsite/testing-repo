import Header from "../components/Header";
import dynamic from "next/dynamic";
import { useState } from "react";
import { useSession } from "next-auth/react";
const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });
import "react-quill/dist/quill.snow.css";
import { useRouter } from "next/router";

export default function NewPost() {
  const { data: session } = useSession();
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  if (!session?.user) {
    return (
      <div>
        <Header />
        <main className="container mx-auto px-4 py-8">
          <p>Please sign in to create a new post.</p>
        </main>
      </div>
    );
  }

  async function createPost() {
    const res = await fetch("/api/posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, content, published: true }),
    });
    if (res.ok) {
      router.push("/");
    } else {
      alert("Error creating post");
    }
  }

  return (
    <div>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-4">New Post</h1>
        <input value={title} onChange={(e) => setTitle(e.target.value)} className="w-full p-2 border mb-4" placeholder="Title" />
        <div className="mb-4">
          <ReactQuill value={content} onChange={setContent} />
        </div>
        <button onClick={createPost} className="px-4 py-2 bg-indigo-600 text-white rounded">Publish</button>
      </main>
    </div>
  );
}